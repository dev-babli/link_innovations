// pages/contact.tsx
"use client";

import React from "react";
import Image from "next/image";
import { User, Mail, Smartphone, MessageSquare } from "lucide-react";
import Footer from "@/components/cortex-sections/footer";
import Navigation from "@/new-src/components/sections/navigation";

const ContactPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 text-gray-900">
      {/* Header / CTA Section */}
      <section className="bg-gradient-to-r from-blue-100 to-blue-500 py-24 relative overflow-hidden">
        {/* Decorative circles */}
        <div className="absolute -top-32 -left-32 w-72 h-72 bg-blue-500 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-pink-200 rounded-full opacity-20 animate-pulse"></div>

        <div className="container mx-auto px-6 lg:flex lg:items-center lg:justify-between gap-12 relative z-10">
          <div className="lg:w-1/2 space-y-6">
            <h1 className="text-5xl md:text-6xl font-extrabold text-gray-900 leading-tight">
              Get in Touch
            </h1>
            <p className="text-lg md:text-xl text-gray-700 space-y-2">
              We'd love to hear from you! Reach out for inquiries, support, or
              to schedule a demo.
            </p>
            <p className="text-lg md:text-xl text-gray-700">
              Our team is ready to provide personalized solutions to help your
              business grow.
            </p>
            <p className="text-lg md:text-xl text-gray-700">
              Contact us today and experience seamless collaboration and prompt
              support.
            </p>

            <div className="flex flex-wrap gap-4">
              <button className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-xl shadow-lg hover:bg-blue-700 transition transform hover:scale-105">
                Talk to Sales
              </button>
              <button className="px-6 py-3 bg-white border border-gray-300 text-gray-900 font-semibold rounded-xl shadow-md hover:bg-gray-50 transition transform hover:scale-105">
                Schedule Demo
              </button>
            </div>
          </div>

          <div className="lg:w-1/2 flex justify-center lg:justify-end mt-10 lg:mt-0">
            <Image
              src="/images/contact.avif"
              alt="Contact Illustration"
              width={700}
              height={400}
              className="rounded-2xl shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* Contact Information + Form */}
      <section className="py-24">
        <div className="container mx-auto px-6 lg:flex lg:gap-16">
          {/* Left Column */}
          <div className="lg:w-1/2 mb-12 lg:mb-0 space-y-6 bg-gray-200 p-8 rounded-2xl shadow-lg border-2 border-green-900">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Contact Information
            </h2>
            <div className="space-y-3 text-gray-700">
              <p>
                <strong>Office Hours:</strong> Mon-Fri 9am-6pm
              </p>
              <p>
                <strong>Support Email:</strong> support@example.com
              </p>
              <p>
                <strong>Sales Email:</strong> sales@example.com
              </p>
              <p>
                <strong>Regional Offices:</strong> New York, London, Singapore
              </p>
            </div>
            <div className="mt-6 rounded-2xl overflow-hidden shadow-2xl">
              <iframe
                className="w-full h-64"
                src="https://maps.google.com/maps?q=New%20York&t=&z=13&ie=UTF8&iwloc=&output=embed"
                loading="lazy"
              />
            </div>
          </div>

          {/* Right Column - Form */}
          <div className="lg:w-1/2 bg-white bg-opacity-80 backdrop-blur-md p-10 rounded-3xl shadow-2xl border-2 border-blue-900">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              Send us a Message
            </h2>
            <form className="space-y-6">
              {/* Name */}
              <div className="relative">
                <User
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                  size={20}
                />
                <input
                  type="text"
                  id="name"
                  placeholder="Your Name"
                  className="peer w-full border border-gray-300 rounded-xl px-10 pt-5 pb-2 text-gray-900 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-md transition"
                />
                <label
                  htmlFor="name"
                  className="absolute left-10 top-2 text-gray-500 text-sm transition-all peer-placeholder-shown:top-5 peer-placeholder-shown:text-gray-400 peer-placeholder-shown:text-base peer-focus:top-2 peer-focus:text-gray-700 peer-focus:text-sm"
                >
                  Name
                </label>
              </div>

              {/* Email */}
              <div className="relative">
                <Mail
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                  size={20}
                />
                <input
                  type="email"
                  id="email"
                  placeholder="you@example.com"
                  className="peer w-full border border-gray-300 rounded-xl px-10 pt-5 pb-2 text-gray-900 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-md transition"
                />
                <label
                  htmlFor="email"
                  className="absolute left-10 top-2 text-gray-500 text-sm transition-all peer-placeholder-shown:top-5 peer-placeholder-shown:text-gray-400 peer-placeholder-shown:text-base peer-focus:top-2 peer-focus:text-gray-700 peer-focus:text-sm"
                >
                  Email
                </label>
              </div>

              {/* Phone */}
              <div className="relative">
                <Smartphone
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                  size={20}
                />
                <input
                  type="tel"
                  id="phone"
                  placeholder="+1 234 567 890"
                  className="peer w-full border border-gray-300 rounded-xl px-10 pt-5 pb-2 text-gray-900 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-md transition"
                />
                <label
                  htmlFor="phone"
                  className="absolute left-10 top-2 text-gray-500 text-sm transition-all peer-placeholder-shown:top-5 peer-placeholder-shown:text-gray-400 peer-placeholder-shown:text-base peer-focus:top-2 peer-focus:text-gray-700 peer-focus:text-sm"
                >
                  Phone
                </label>
              </div>

              {/* Message */}
              <div className="relative">
                <MessageSquare
                  className="absolute left-3 top-3 text-gray-400"
                  size={20}
                />
                <textarea
                  id="message"
                  rows={5}
                  placeholder="Write your message..."
                  className="peer w-full border border-gray-300 rounded-xl px-10 pt-5 pb-2 text-gray-900 placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 shadow-md transition resize-none"
                />
                <label
                  htmlFor="message"
                  className="absolute left-10 top-2 text-gray-500 text-sm transition-all peer-placeholder-shown:top-5 peer-placeholder-shown:text-gray-400 peer-placeholder-shown:text-base peer-focus:top-2 peer-focus:text-gray-700 peer-focus:text-sm"
                >
                  Message
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-600 text-white font-semibold rounded-2xl shadow-lg hover:bg-blue-700 transition transform hover:scale-105"
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Trusted By / Statistics */}
      <section className="py-20 bg-gray-50 text-center">
        <h2 className="text-3xl font-semibold mb-10">Trusted By Industries</h2>

        {/* Logos */}
        <div className="flex flex-wrap justify-center items-center gap-8 mb-12">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/4/4a/Logo_2013_Google.png"
            alt="Google"
            className="h-12 grayscale hover:grayscale-0 transition"
          />

          <img
            src="https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg"
            alt="Apple"
            className="h-12 grayscale hover:grayscale-0 transition"
          />
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg"
            alt="Amazon"
            className="h-12 grayscale hover:grayscale-0 transition"
          />
        </div>

        {/* Statistics */}
        <div className="mt-12 flex flex-wrap justify-center gap-12">
          <div>
            <h3 className="text-4xl font-bold text-blue-600">500+</h3>
            <p>Projects Completed</p>
          </div>
          <div>
            <h3 className="text-4xl font-bold text-blue-600">200+</h3>
            <p>Happy Clients</p>
          </div>
          <div>
            <h3 className="text-4xl font-bold text-blue-600">10+</h3>
            <p>Years of Experience</p>
          </div>
        </div>
      </section>

      {/* CTA / Innovation Prompt - Gray Background with White Text */}
      <section className="relative py-28 text-white overflow-hidden px-6 md:px-16 lg:px-32">
        {/* Animated background circles */}
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-pink-500 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-blue-500 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute top-1/2 left-1/4 w-64 h-64 bg-gradient-to-tr from-purple-500 via-pink-500 to-red-500 rounded-full opacity-30 animate-spin-slow"></div>

        <div className="relative z-10 max-w-4xl mx-auto text-center flex flex-col items-center gap-6">
          {/* Glass card effect */}
          <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-3xl p-10 shadow-2xl flex flex-col items-center gap-6">
            <h2 className="text-5xl md:text-6xl font-extrabold drop-shadow-lg">
              Ready to Innovate?
            </h2>
            <p className="max-w-3xl text-lg md:text-xl text-balck/90">
              Join us today and transform your ideas into real-world solutions
              with speed and confidence.
            </p>
            <div className="flex flex-wrap justify-center gap-6 mt-4">
              <button className="px-10 py-4 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white font-bold rounded-3xl shadow-lg hover:shadow-xl hover:scale-105 transition transform">
                Get Started
              </button>
              <button className="px-10 py-4 bg-black text-white font-bold rounded-3xl shadow-lg backdrop-blur-md hover:bg-white/30 hover:scale-105 transition transform">
                Learn More
              </button>
            </div>
          </div>
        </div>

        {/* Floating geometric shapes */}
        <div className="absolute top-10 left-10 w-6 h-6 bg-white rounded-full opacity-30 animate-bounce-slow"></div>
        <div className="absolute bottom-20 right-16 w-8 h-8 bg-white/50 rounded-full animate-bounce-slow delay-500"></div>
        <div className="absolute top-1/3 right-1/4 w-10 h-10 border-2 border-white/20 rounded-full animate-spin-slow"></div>
      </section>
      <Footer />
    </div>
  );
};

export default ContactPage;
